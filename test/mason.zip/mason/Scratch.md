# Scratch

Run "Mason: Paste and format" with your cursor on the line below.


