# Footnotes — collision test

This note already has two footnotes.[^1][^2] Paste/transform a Perplexity block
here (or run a Perplexity script on a pasted selection) and the NEW footnotes must
start at 3+, never collide with these.

[^1]: Existing source one.
[1](https://example.com/one)
[^2]: Existing source two.
[2](https://example.com/two)
