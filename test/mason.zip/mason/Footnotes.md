# Footnotes test

A claim that needs a source.[^1] Another claim.[^second] A repeat of the
first source.[^1]

A duplicate-definition case below[^dup] and again[^dup].

Out-of-order reference appears first[^z] then earlier[^a].

[^1]: First source.
[^second]: Named footnote.
[^dup]: Defined twice on purpose.
[^dup]: Second definition — dedup should collapse these.
[^z]: Later letter.
[^a]: Earlier letter.
