# Markdown Mason — Dev Test Vault

Throwaway vault for manually exercising the plugin during development.

- The plugin lives in `.obsidian/plugins/markdown-mason/`. `main.js` + `manifest.json`
  are **copied** there by `esbuild.config.mjs` on every build (not symlinked —
  Electron's loader doesn't follow symlinked plugin files reliably; this mirrors
  how `miyo-kado` does it).
- The vault's `manifest.json` is dev-stamped (`0.0.1-dev.<timestamp>`) on each build
  so **Hot Reload** (`pjeby/hot-reload`) always sees a fresh version. The `.hotreload`
  marker in the plugin folder tells Hot Reload to watch this plugin.
- Run `npm run dev` in the repo root → edits rebuild and auto-copy here → Hot Reload
  reloads the plugin in place. No manual disable/enable.
- This whole folder (`test/mason/`) is gitignored — edit freely.

Open: Obsidian → "Open folder as vault" → select `test/mason`.

## Sample notes
- `Heading cascade.md` — exercises the heading-level cascade transform.
- `Footnotes.md` — exercises footnote renumbering and dedup.
