# Tidy footnotes — accumulated

This note drifted over several pastes: footnote numbers are gappy ([^2], [^5], [^7]),
one source URL is duplicated, definitions sit scattered in the body, and there's a
hand-written alpha annotation [^A]. Run **Tidy footnotes** (Cmd/Ctrl+P).

Expected: numeric footnotes renumber **gap-free** in first-reference order, the
**duplicate URL merges** to a single footnote (both refs point to it), **[^A] is left
untouched** (not renumbered, not moved), and every definition files into **## Resources**
in the two-line format — all as **one** undoable edit, with a "Mason: N footnotes filed" Notice.

---

Tokyo sakura peak is forecast for late March.[^2] More detail from another forecaster.[^5]
A later claim reuses the very first source.[^7] And an annotation I added by hand.[^A]

[^2]: thestar.com
[thestar.com](https://www.thestar.com.my/sakura-2026)
[^5]: n-kishou
[n-kishou](https://n-kishou.com/sakura)
[^7]: thestar again — same URL as [^2], should dedup
[thestar.com](https://www.thestar.com.my/sakura-2026)
[^A]: My own annotation — never renumbered or moved.
