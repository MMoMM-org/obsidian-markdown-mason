# 🧪 Markdown Mason — first live test

The current build (settings header + the two latest fixes) is already deployed here.
All commands are run from the **command palette**: `Cmd/Ctrl + P`, then type "Mason:".

---

## 0. Open & enable (one-time)

1. Obsidian → **Open folder as vault** → select this `test/mason` folder. Trust the vault if asked.
2. **Settings → Community plugins** → make sure **Markdown Mason** and **Hot Reload** are both enabled.
3. **Settings → Markdown Mason** → you should see, top to bottom:
   - **Header**: `Markdown Mason v0.0.1-dev.… · Marcus Breiden · Documentation` + tagline *"Reshape pasted Markdown to fit your note."*
   - **General** (Resources section name, Numeric-only footnotes)
   - **Scripts** → "No scripts installed yet" *(expected — built-in Perplexity scripts are commands, not listed here yet; that's the v0.2 redesign)*
   - **Advanced** (Debug logging)

---

## 1. Headline flow — Paste and format (clipboard → auto-detect)

1. Open `TestMaterial/sakura-in-tokyo-app.md` → `Cmd+A` `Cmd+C` (copy the raw Perplexity text).
2. Open `Scratch.md` → click the empty line so the cursor is there.
3. `Cmd+P` → **Mason: Paste and format** → Enter.

**Expect:**
- The block is inserted **restructured**: inline `[1][2]…` citations become `[^1][^2]…` footnotes; a **`## Resources`** section is appended with two-line `[^n]:` definitions; the raw `Sources` list is gone.
- A **Notice** pops: `Mason: N changes` ← *(new this build — success notice)*
- `Cmd+Z` **once** reverts the whole thing in a single undo. ← *(atomicity check)*

Repeat with `sakura-in-tokyo-web.md` and `sakura-in-tokyo-web-download.md` — auto-detect should handle all three.

---

## 2. Selection flow — Perplexity scripts

1. In `Scratch.md`, paste a raw fixture as **plain text** (`Cmd+Shift+V`), then **select** the whole block.
2. `Cmd+P` → **Mason: Perplexity auto** (auto-detect) — or the specific **Mason: Perplexity app / web / web download**.

**Expect:** same restructured output as §1, transforming the **selection in place** + count Notice + single undo.

---

## 3. Footnote collision — the new DRIFT-2 fix

1. Open **`Footnotes — collision test.md`** (it already has `[^1]` and `[^2]`).
2. Copy a raw fixture (`TestMaterial/…app`) to the clipboard.
3. Put the cursor at the **end of the note** → **Mason: Paste and format**.

**Expect:** the new footnotes start at **`[^3]` and up** — **never** a second `[^1]`. The existing `[^1]`/`[^2]` stay untouched. (Before the fix, this collided.)

---

## 4. Heading cascade

1. Open `Heading cascade.md` (has `####`/`######` jumps under an H1).
2. Select the region to fix (or the whole note) → **Mason: Cascade headings** (or **Mason: Normalize headings**).

**Expect:** nested heading levels cascade to sensible depths relative to the heading above the cursor; a Notice reports the change; one undo reverts.

---

## 5. Tidy footnotes — whole-note O+D

1. Open `Footnotes.md` (duplicate `[^dup]` definitions, out-of-order refs, alpha footnotes).
2. `Cmd+P` → **Mason: Tidy footnotes**.

**Expect:** numeric footnotes renumbered **gap-free**, duplicate **definitions deduped**, definitions filed under **`## Resources`**. **Alpha** footnotes (`[^second]`, `[^a]`, `[^z]`, `[^dup]`) are **preserved and not renumbered**. Notice + single undo.

---

## 6. Failure / edge modes (should degrade gracefully)

- **Empty clipboard** → *Mason: Paste and format* → Notice "clipboard is empty", no edit.
- **Non-Perplexity clipboard** → *Paste and format* just inserts the raw text (no crash).
- **Perplexity app** on a non-Perplexity selection → no-op (nothing changes, no error).
- **Advanced → Debug logging ON**, reload Obsidian, open devtools (`Cmd+Opt+I`) → look for `[MarkdownMason]` traces.

---

## What to capture for me
For anything off: the **command name**, the **input** (which note/fixture), what you **expected vs. saw**, and any **console error** (devtools). Screenshots welcome.

> Note: this vault is gitignored; these helper notes won't survive re-unzipping `test/mason.zip` unless you refresh it. The plugin auto-reloads on every `npm run build` (Hot Reload).
